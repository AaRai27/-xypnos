/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exypnos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author Afif Raihan
 */
public class Controller implements ActionListener{
    
    GUI_Login view;
    GUI_Admin viewAdmin = new GUI_Admin();
    
    public Controller() {
        view = new GUI_Login();
        view.addActionListener(this);
        view.setVisible(true);
        view.resetView();
        view.showTime();
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Calendar now = Calendar.getInstance();
        System.out.println(dateFormat.format(now.getTime()));
        Object login = ae.getSource();
        if(login.equals(view.getBtnLogin())){
            if(view.getUsernameLogin().equals("admin") && view.getPasswordLogin().equals("admin")){
                viewAdmin.setVisible(true);
            }else{
                view.statusViewSalah();
            }
            
        }
    }
    
    
    
}
