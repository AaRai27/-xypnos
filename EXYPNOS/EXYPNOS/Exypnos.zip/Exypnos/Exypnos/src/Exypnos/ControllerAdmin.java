/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exypnos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Afif Raihan
 */
public class ControllerAdmin implements ActionListener{

    GUI_Admin viewAdmin;

    public ControllerAdmin() {
        viewAdmin = new GUI_Admin();
        viewAdmin.addActionListener(this);
        viewAdmin.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        Object button = ae.getSource();
        if(button.equals(viewAdmin.getBtnLihatKelas())){
            viewAdmin.tampilkanHasil("Kelas");
        }else if(button.equals(viewAdmin.getBtnLihatMapel())){
            viewAdmin.tampilkanHasil("Mapel");
        }else if (button.equals(viewAdmin.getBtnLihatTentor())){
            viewAdmin.tampilkanHasil("Tentor");
        }else{
            viewAdmin.tampilkanHasil("Siswa");
        }
    }
    
}
